const nextConfig = {
  images: {
    domains: ['images.pexels.com'], // Add this line
  },
};

export default nextConfig;

