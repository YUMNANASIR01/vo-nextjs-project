(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_b90be85d._.js",
  "static/chunks/src_components_ui_055a1d8f._.js"
],
    source: "dynamic"
});
